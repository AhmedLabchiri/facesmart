import mysql.connector
mydb = {
    'user': 'root',
    'password': '1302',
    'host': 'localhost',
    'auth_plugin': 'caching_sha2_password',  # Specify the plugin explicitly
    'database':'testdb'
}

try:
    connection = mysql.connector.connect(**mydb)
    mycursor = connection.cursor()

except mysql.connector.Error as err:
    print(f"Error: {err}")

