import cv2
import numpy as np
import face_recognition
import os
from datetime import datetime
import tkinter as tk
import util
from PIL import Image, ImageTk
import mysql.connector
from tkinter import PhotoImage
from tkinter import ttk
class DatabaseHandler:
    def __init__(self, host, user, passwd, database):
        self.connection = mysql.connector.connect(
            host = host,
            user = user,
            passwd=passwd,
            database=database
        )
        self.cursor = self.connection.cursor()

    def queryExec(self,query,params=None):
        self.cursor.execute(query,params)
        return self.cursor.fetchall()
    def commit(self):
        self.connection.commit()
    def closeConnection(self):
        self.cursor.close()
        self.connection.close()

class App:
    def __init__(self, db):

        self.main_window = tk.Tk()
        self.main_window.geometry("1200x520+350+100")
        self.main_window.title("Main Window")
        self.main_window.iconbitmap(r'../icons/face_detect.ico')
        self.imgpath= PhotoImage(file=r"C:\Ahmed Space\updated\facesmart\bg.png")
        self.backimage = tk.Label(self.main_window, image=self.imgpath)
        self.backimage.place(relheight=1, relwidth=1)
        self.login_butt_main = util.get_button(self.main_window,"Log In","red",self.login,)
        self.login_butt_main.place(x=830,y=300)
        """#self.register_butt_main = util.get_button(self.main_window, "Register", "green", self.register, )"""

        self.register_butt_main = util.get_button(self.main_window, "Register", "green" , self.register, )
        self.register_butt_main.place(x=830, y=400)
        self.webcam=util.get_img_label(self.main_window)
        self.webcam.place(x=10,y=0, width=700, height=500)
        self.faceweb(self.webcam)
        self.db_dir = "../facestoload"
        self.entryText = util.get_entry_textT(self.main_window)
        self.entryText.place(x=800,y=150)
        """!!!!!!!"""
        self.pwd = self.entryText.get(1.0, "end-1c")
        print(self.pwd)
        self.textforusername = util.get_text_label(self.main_window, "Please input password \n(for admin only)")
        self.textforusername.place(x=800,y=75)

        if not os.path.exists(self.db_dir):
            os.mkdir(self.db_dir)
        self.db = db
        "#Init"
        self.imagesList = []
        self.namesList = []
        self.lName = os.listdir(self.db_dir)
        for self.lN in self.lName:
            self.curImg = cv2.imread(f'{self.db_dir}/{self.lN}')
            self.imagesList.append(self.curImg)
            self.namesList.append(os.path.splitext(self.lN)[0])




    def faceweb(self, label):
        if "cap" not in self.__dict__:
            self.cap = cv2.VideoCapture(0)
        self._label = label
        self.place_webcam()

    def imageEncoding(self):
        self.encodeList = []
        for self.img in self.imagesList:
            self.img = cv2.cvtColor(self.img, cv2.COLOR_BGR2RGB)
            self.faceEncode = face_recognition.face_encodings(self.img)[0]
            self.encodeList.append(self.faceEncode)
        return self.encodeList
    def place_webcam(self):
        success, frame = self.cap.read()
        self.recent_cap = frame
        img = cv2.cvtColor(self.recent_cap,cv2.COLOR_BGR2RGB)
        self.recent_cap_pil = Image.fromarray(img)
        imgTk = ImageTk.PhotoImage(image=self.recent_cap_pil)
        self._label.imgtk = imgTk
        self._label.configure(image=imgTk)
        self._label.after(20, self.place_webcam)

        self.imgSize = cv2.resize(frame, (0, 0), None, 0.25, 0.25)
        self.imgSize = cv2.cvtColor(self.imgSize, cv2.COLOR_BGR2RGB)





    def start(self):
        self.main_window.mainloop()
    def login(self):
        self.facesInFrame = face_recognition.face_locations(self.imgSize)
        self.encodeInFrame = faceEncode = face_recognition.face_encodings(self.imgSize, self.facesInFrame)
        self.KnownFaces = self.imageEncoding()

        '#compare capture to known faces in the system'
        for self.encodeFace, self.faceLoc in zip(self.encodeInFrame, self.facesInFrame):
            self.faceMatches = face_recognition.compare_faces(self.KnownFaces, self.encodeFace)
            self.faceDis = face_recognition.face_distance(self.KnownFaces, self.encodeFace)
            self.matchI = np.argmin(self.faceDis)

            if self.faceMatches[self.matchI]:
                self.name = self.namesList[self.matchI].upper()
                self.markAttendance()
                y1, x2, y2, x1 = self.faceLoc
                y1, x2, y2, x1 = y1 * 4, x2 * 4, y2 * 4, x1 * 4
                cv2.rectangle(self.recent_cap, (x1, y1), (x2, y2), (255, 0, 255), 2)
                cv2.rectangle(self.recent_cap, (x1, y2 - 30), (x2, y2), (255, 0, 255), cv2.FILLED)
                cv2.putText(self.recent_cap, self.name, (x1 + 6, y2 - 6), cv2.FONT_HERSHEY_COMPLEX, 1, (255, 255, 255), 2)
                if self.name == "ADMIN":
                    print(self.pwd)
                    self.login_dashboard()
                else:
                    util.msg_box("Login Success!", "Attendance Marked! Welcome back, " + self.name)


            else:
                util.msg_box("Login Failed!", "We couldn't capture or identify you, please try again or register")

    def markAttendance(self):
        with open('../attendance.csv', 'r+') as f:
            self.DataList = f.readlines()
            self.names = []
            for line in self.DataList:
                entry = line.split(',')
                self.names.append(entry[0])
                self.now = datetime.now()
                self.dtimes = self.now.strftime('%H:%M:%S')
                f.writelines(f'\n{self.name},{self.dtimes}')
                break

    def register(self):
        self.register_window = tk.Toplevel(self.main_window)
        self.register_window.geometry("1200x520+370+120")
        #entry and others
        self.entryText = util.get_entry_text(self.register_window)
        self.entryText.place(x=750,y=150)

        self.textforusername = util.get_text_label(self.register_window, "Please input username")
        self.textforusername.place(x=750,y=70)

        #Accept Button

        self.name_butt = util.get_button(self.register_window, "Accept", "green", self.accept_register, )
        self.name_butt.place(x=800, y=300)

        #Try Again Button
        self.confirm_butt_main = util.get_button(self.register_window, "Try Again", "red", self.retry_register, )
        self.confirm_butt_main.place(x=800, y=400)
        #the screenshot from cv2
        self.sc = util.get_img_label(self.register_window)
        self.sc.place(x=10, y=0, width=700, height=500)
        self.addsc(self.sc)
    def addsc (self,label):
        imgTk = ImageTk.PhotoImage(image=self.recent_cap_pil)
        label.imgtk = imgTk
        label.configure(image=imgTk)
        self.register_cap = self.recent_cap.copy()
    def insert_query(self,var,query):
        print("insert query function entered")
        self.db.queryExec(query, var)
        self.db.commit()

    def accept_register(self):
        self.nameToUse = self.entryText.get(1.0, "end-1c")
        if self.nameToUse == "ADMIN":
            util.msg_box("Privilege Error!","You can't register as an Admin, please use your real name instead.")
            self.register_window.destroy()
        else:
            print(self.nameToUse)
            cv2.imwrite(os.path.join(self.db_dir, "{}.jpg".format(self.nameToUse)), self.register_cap)
            util.msg_box("Success!", "User was registered succesfully")
            var = (self.nameToUse,)
            query = """INSERT INTO users(username) VALUES(%s)"""
            self.insert_query(var,query)
            self.register_window.destroy()
            """query ='''INSERT INTO users(username) VALUES(%s)'''
            
            self.db.queryExec(query,var)
            self.db.commit()
            self.register_window.destroy()"""


    def retry_register(self):
        self.register_window.destroy()
    def login_dashboard(self):
        print("Entered")
        self.dashboard_window= tk.Toplevel(self.main_window)
        self.dashboard_window.geometry("1200x520+370+120")
        self.backimage = tk.Label(self.dashboard_window, image=self.imgpath)
        self.backimage.place(relheight=1, relwidth=1)
        self.dashboard_window.title("Dashboard")
        self.dashboard_window.iconbitmap(r'../icons/face_detect.ico')
        self.imgpath = PhotoImage(file=r"C:\Ahmed Space\updated\facesmart\bg.png")
        self.backimage = tk.Label(self.dashboard_window, image=self.imgpath)
        self.create_butt = util.get_button_CRUD(self.dashboard_window,"Create","green",self.create_CRUD)
        self.create_butt.place(x="40",y="20")
        self.read_butt = util.get_button_CRUD(self.dashboard_window, "Read", "blue", self.read_CRUD)
        self.read_butt.place(x="40", y="90")
        self.update_butt = util.get_button_CRUD(self.dashboard_window, "Update", "black", self.create_CRUD)
        self.update_butt.place(x="40", y="160")
        self.delete_butt = util.get_button_CRUD(self.dashboard_window, "Delete", "red", self.create_CRUD)
        self.delete_butt.place(x="40", y="230")

    def create_CRUD(self):
        """Create"""
        self.createform = util.create_form_label(self.dashboard_window,"Enter the full name of the student")
        self.createform.place(x="220",y="20")
        self.creatEntry_name = util.get_entry_create(self.dashboard_window)
        self.creatEntry_name.place(x="530",y="20")

        """Departement"""
        self.creatDepartment = util.create_form_label(self.dashboard_window,"Enter the major of choice")
        self.creatDepartment.place(x="220",y="60")
        self.creatDepartment_entry = util.get_entry_create(self.dashboard_window)
        self.creatDepartment_entry.place(x="530", y="60")

        """Year of registering to the institution"""
        self.creatReg = util.create_form_label(self.dashboard_window, "Enter the year of registration")
        self.creatReg.place(x="220", y="100")
        self.creatReg_entry = util.get_entry_create(self.dashboard_window)
        self.creatReg_entry.place(x="530", y="100")
        self.accept_butt = util.get_button(self.dashboard_window, "Accept", "green",self.confirm_create, )
        self.accept_butt.place(x="800", y="300")


        """"""
    def confirm_create(self):
        self.EntryName = self.creatEntry_name.get(1.0, "end-1c")
        self.EntryDepartment = self.creatDepartment_entry.get(1.0, "end-1c")
        self.EntryYear = self.creatReg_entry.get(1.0, "end-1c")
        print("hey", self.EntryDepartment, self.EntryYear, self.EntryName)
        queryy = """INSERT INTO users(username, major, yearr) VALUES(%s,%s,%s)"""
        varr = (self.EntryName, self.EntryDepartment, self.EntryYear)
        self.insert_query(varr, queryy)

    def read_query(self):
        print("read query function entered")
        queryy = """SELECT * FROM users WHERE major = %s"""
        param = ' Software Engineer'
        rows = self.db.queryExec(queryy ,(param,))
        return rows
    def on_select(self,event):
        self.selected_item = self.optionchoosen.get()
        print("Selected Item:", self.selected_item)  # Add a print statement to check if the function is being called
        if self.selected_item == ' Software Engineer':
            x=230
            y=70
            self.table_read = util.tree_read(self.dashboard_window,x,y)
            self.read_query()
            print("1")
        elif self.selected_item == ' MBA':
            print("2")
        elif self.selected_item == ' Computer Science':
            print("3")
        elif self.selected_item == ' Applied Mathematics':
            print("4")





    def dropdown(self):
        self.labelfordropdown = ttk.Label(self.dashboard_window, text="Filter by major:", font=("Helvetica bold", 15))
        self.labelfordropdown.place(x="230", y="30")
        n = tk.StringVar()
        self.optionchoosen = ttk.Combobox(self.dashboard_window, width=27,
                                     textvariable=n)
        self.optionchoosen['values'] = (' Software Engineer',
                                   ' MBA',
                                   ' Computer Science',
                                   ' Applied Mathematics'
                                   )

        self.optionchoosen.grid(column=1, row=15)
        self.optionchoosen.place(x="390", y="35")
        self.optionchoosen.bind("<<ComboboxSelected>>", self.on_select)

    def read_CRUD(self):
        self.dropdown()




if __name__=="__main__":
    db = DatabaseHandler("localhost", "root", "1302", "testdb")
    app=App(db)
    app.start()



