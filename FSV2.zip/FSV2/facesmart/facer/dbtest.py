import mysql.connector


class DatabaseHandler:
    def __init__(self, host, user, passwd, database):
        self.connection = mysql.connector.connect(
            host = host,
            user = user,
            passwd=passwd,
            database=database
        )
        self.cursor = self.connection.cursor()

    def queryExec(self,query,params=None):
        self.cursor.execute(query,params)

    def commit(self):
        self.connection.commit()
    def closeConnection(self):
        self.cursor.close()
        self.connection.close()




